<?php
session_start();

 if( !isset($_SESSION["login"]) ) {
 	header("location: login_admin.php");
 	exit;
 }
//Connet To Databases
require 'function.php';
//Tombol Submit mengecek sudah di tekan atau belum
if( isset($_POST["submit"]) ) {
//Pengecekan Berhasil Apa gagal
	if( tambah($_POST) > 0 ) {
		print "
			<script>
				alert('Data Berhasil Ditambahkan!');
				document.location.href = 'halaman_admin.php';
			</script>
		";
	} else {
		print "
			<script>
				alert('Data Gagal Ditambahkan!');
				document.location.href = 'halaman_admin.php';
			</script>
		";
	}
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="css/tambah.css">
<title>HALAMAN ADD</title>
</head>
<body>
	<form method="post" action="" enctype="multipart/form-data">
	 <div class="container">
    <div class="row">
      <div class="col-lg-10 col-xl-9 mx-auto">
        <div class="card card-signin flex-row my-5">
          <div class="card-img-left d-none d-md-flex">
             <!-- Background image for card set in CSS! -->
          </div>
          <div class="card-body">
            <h5 class="card-title text-center">TAMBAH DATA BARANG</h5>
            <form action="" method="post" class="form-signin">
              <div class="form-label-group">
              	 <label for="Barang">masukan nama barang</label>
                <input type="text" id="Barang" class="form-control" name="Barang" placeholder="Barang" required autofocus>
              </div>
              
              <div class="form-label-group">
              	 <label for="Stok">Masukan stok barang</label>
                <input type="text" id="Stok" name="Stok" class="form-control" placeholder="Stok" required>
              </div>
              
              <div class="form-label-group">
              	 <label for="Harga">masukan harga</label>
                 <input type="text" id="Harga" name="Harga" class="form-control" placeholder="Harga" required>
              </div>

              <div class="form-label-group">
              	<label for="Terjual">masukan baranag terjual</label>
                 <input type="text" id="Terjual" name="Terjual" class="form-control" placeholder="Terjual" required>
              </div>

              <div class="form-label-group">
              	 <label for="Merk">masukan merk</label>
                 <input type="text" id="Merk" name="Merk" class="form-control" placeholder="Merk" required>
              </div>
              <br>

              <div class="custom-file">	 
				      <input class="custom-file-input" type="file" name="Foto" id="Foto" required >
               <label class="custom-file-label" for="Foto">Masukan Foto </label> 
			     	</div>
             <img src="" name="Foto" width="80">
            <br>

              <button class="btn btn-lg btn-dark btn-block text-uppercase" type="submit" name="submit">ADD</button><br>
               <button type="button" class="btn btn-lg btn-dark btn-block text-uppercase"> <a href="halaman_admin.php">TIDAK JADI MENAMBAHKAN</a></button>
              <a class="d-block text-center mt-2 small"> </a>
              <hr class="my-4">
             
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
	
	  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	
</body>
</html>