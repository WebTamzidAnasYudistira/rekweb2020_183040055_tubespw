-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2020 at 03:27 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw_183040055`
--

-- --------------------------------------------------------

--
-- Table structure for table `elektronik`
--

CREATE TABLE `elektronik` (
  `Id` int(11) NOT NULL,
  `Nama_barang` varchar(64) NOT NULL,
  `Merk_barang` varchar(64) NOT NULL,
  `Kode_barang` varchar(64) NOT NULL,
  `Harga` int(32) NOT NULL,
  `Foto` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elektronik`
--

INSERT INTO `elektronik` (`Id`, `Nama_barang`, `Merk_barang`, `Kode_barang`, `Harga`, `Foto`) VALUES
(1, 'Smartphone', 'Samsung', 'J6plus', 2300000, 'a.jpg'),
(2, 'Tv led', 'Polytron 43 in', ' PLD43V863', 3500000, 'b.jpg'),
(3, 'tv led', 'samsung 24 in', 'UA24H4150', 1500000, 'c.jpg'),
(4, 'tv led', 'LG 32 in', '32LJ500D', 2000000, 'd.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `elektronik2`
--

CREATE TABLE `elektronik2` (
  `Id` int(11) NOT NULL,
  `Barang` int(11) NOT NULL,
  `Unit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `elektronik3`
--

CREATE TABLE `elektronik3` (
  `Id` int(11) NOT NULL,
  `Barang` varchar(64) NOT NULL,
  `Unit` int(32) NOT NULL,
  `Harga` int(32) NOT NULL,
  `Penjualan` int(32) NOT NULL,
  `Foto` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elektronik3`
--

INSERT INTO `elektronik3` (`Id`, `Barang`, `Unit`, `Harga`, `Penjualan`, `Foto`) VALUES
(1, 'setrika baju', 10, 200000, 3, 'a.jpg'),
(2, 'Tv led', 5, 2500000, 6, 'b.jpg'),
(3, 'DVD', 7, 600000, 8, 'c.jpg'),
(4, 'Laptop', 4, 3500000, 5, 'd.jpg'),
(5, 'AC', 7, 7000000, 4, 'e.jpg'),
(6, 'Kipas', 5, 300000, 3, 'f.jpg'),
(7, 'Playstation4', 5, 4000000, 2, 'g.jpg'),
(8, 'Printer', 7, 3500000, 3, 'h.jpg'),
(9, 'Mesin cuci', 10, 3200000, 5, 'i.jpg'),
(11, 'Keyboard', 3, 200000, 2, 'k.jpg'),
(12, 'mouse', 11, 100000, 5, 'k.jpg'),
(13, 'smartphone', 11, 3500000, 4, 'E');

-- --------------------------------------------------------

--
-- Table structure for table `elektronik4`
--

CREATE TABLE `elektronik4` (
  `id` int(11) NOT NULL,
  `Barang` varchar(64) NOT NULL,
  `Stok` int(32) NOT NULL,
  `Harga` int(32) NOT NULL,
  `Terjual` int(32) NOT NULL,
  `Foto` varchar(100) NOT NULL,
  `Merk` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elektronik4`
--

INSERT INTO `elektronik4` (`id`, `Barang`, `Stok`, `Harga`, `Terjual`, `Foto`, `Merk`) VALUES
(2, 'Tv Led ', 60, 3500000, 12, '5cc6c93f02282.jpg', 'LG'),
(3, 'DVD', 13, 500000, 3, 'c.jpg', 'Sony'),
(4, 'Laptop Rog', 20, 5000000, 5, '5cc9a980cbea1.jpg', 'Asus'),
(5, 'Komputer', 9, 7000000, 4, '5cc919fbf309f.jpg', 'Samsung'),
(6, 'Printer', 12, 4500000, 8, '5cc1eb8273de1.jpg', 'Epson'),
(7, 'Camera ', 43, 4000000, 20, '5cc92fdcef43b.jpg', 'Canon'),
(8, 'Speaker', 23, 1200000, 13, '5cc6c95f9afbf.jpg', 'Polytron'),
(9, 'AC', 10, 7000000, 9, '5cc2d1557a723.jpg', 'LG'),
(10, 'Playstation4', 13, 5000000, 10, '5cc1ebd2b09ad.jpg', 'Sony'),
(18, 'Mouse Gaming', 25, 250000, 15, '5cc2d1693571f.jpg', 'Rexus'),
(19, 'Keyboard Gaming', 50, 350000, 20, '5cc6fc6831ce2.png', 'Rexus'),
(20, 'Headset Gaming', 30, 240000, 17, '5cc2d19419f8c.jpg', 'Rexus'),
(21, 'Monitor Gaming', 35, 3200000, 22, '5cc2d1aac9e15.jpg', 'DELL'),
(22, 'Smartphone', 90, 3000000, 10, '5cc92fc2e18bb.jpg', 'LG'),
(23, 'Smartwatch', 20, 3300000, 12, '5cc9b85a2f9bf.jpg', 'Samsung'),
(27, 'Infocus', 60, 1750000, 35, '5cc2d2054363d.png', 'Epson'),
(28, 'Mesin cuci', 11, 3700000, 5, '5cc26268334a0.jpg', 'LG'),
(29, 'Kulkas', 25, 4000000, 17, '5cc2d21a21d05.jpg', 'Polytron'),
(30, 'Setrika', 7, 270000, 2, '5cc2d2307e0af.jpg', 'Philips'),
(31, 'Kipas', 10, 540000, 4, '5cc2d24336634.jpg', 'Miyako'),
(34, 'Radio', 50, 500000, 17, '5cc9120c5ec9a.jpeg', 'Sony'),
(35, 'Blender', 67, 750000, 20, '5cc9132f49734.png', 'Miyako'),
(36, 'Dispenser', 27, 1000000, 7, '5cc913fbcedde.jpg', 'Sanken'),
(37, 'Rice Cooker', 31, 870000, 10, '5cc9152069e25.jpeg', 'Sanken'),
(38, 'Microwave', 22, 2000000, 12, '5cc9166aeeec9.jpg', 'Samsung'),
(39, 'Drone', 17, 9700000, 6, '5cc98c1a84f08.jpg', 'Cherson');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nrp` char(9) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `jurusan` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nrp`, `nama`, `email`, `jurusan`) VALUES
(1, '183040055', 'anas', 'anas123@gmail.com', 'Teknik informatika'),
(2, '183040099', 'genji', 'gejiyaaa12@gmail.com', 'Teknik mesin'),
(3, '183040077', 'naruto', 'uzumakinaruto@gmail.com', 'Teknik mesin'),
(4, '183040067', 'yamato boyen', 'boyen_yamato12@gmail.com', 'Teknik informatika'),
(5, '183040022', 'asgar thor', 'asgar_thor@gmail.com', 'Teknik pangan'),
(6, '183040066', 'hadi', 'hadi@gmail.com', 'Teknik pangan'),
(7, '183040034', 'sandi', 'sandi123@gmail.com', 'Teknik industri');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'anas', '$2y$10$TAA01NGJSh8EAaSuQUbi5OIZfsce8UGZcqDclq2xM4IsUTgShVtCe'),
(2, 'admin', '$2y$10$jaIFh.l1uAbmNLwVqWgDzuah.AX/AoANA8qOH6mAl7i.WJ0MUSbDy'),
(3, 'tes', '$2y$10$G7l8K7oLQzM2RhH7Tk/5n.k7H6FM9YiNJpNXOFujimptihLH8ehjC'),
(4, 'cek', '$2y$10$SKWSwh4bpFwctezT7F1E2.6DLzCgOPVYsp12gXCD2yNxJ4nZRMsj2'),
(5, 'syamsul', '$2y$10$prNj3Ef5/Od81DrNdTQIUuz7rdPTQiN/O3fbT9NAEf9jqMgORSPga'),
(6, 'deni', '$2y$10$VoG6Vn9RQ0HDY6b0Xt8oM.sILA.qNcMnzccNuzOv9GUgzDbeYIz2.'),
(7, 'reza', '$2y$10$22z/unwwS964p.c3EJK1HuijHE319BivBonwbTTH9V7lQakEIZ60q'),
(8, 'walker cans', '$2y$10$oiksp/nWiCHviReP2CQAe.azoS7j89hZ1uzGOBtE0/WUmLpit7ymu'),
(9, 'adut', '$2y$10$rx1dKdS2WXgRWII/t3RLl.oX14Y/klRye5zjHtViXrcCX2kqZYxIy'),
(10, 'ava', '$2y$10$w1eQ2iX2dhaaga8KO9u0/OMa7/PLzHetXHwgXsy7Uuz5fozxkix.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `elektronik`
--
ALTER TABLE `elektronik`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `elektronik3`
--
ALTER TABLE `elektronik3`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `elektronik4`
--
ALTER TABLE `elektronik4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `nama` (`nama`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `elektronik`
--
ALTER TABLE `elektronik`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `elektronik3`
--
ALTER TABLE `elektronik3`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `elektronik4`
--
ALTER TABLE `elektronik4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
